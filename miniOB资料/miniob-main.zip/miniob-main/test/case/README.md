# miniob-test
miniob自动化功能测试
使用方法参考 miniob_test.py

