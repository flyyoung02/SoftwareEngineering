# OceanBase大赛测试环境说明

> NOTE: miniob代码本身可以在Linux/MacOS上编译测试。

后台测试环境说明：

操作系统：Linux version 4.19.91-23.al7.x86_64

编译器：gcc-8.3.0 （使用clang的同学注意，编译结果可能与gcc稍有不同)

cmake: 3.20.52

make: GNU Make 3.82
